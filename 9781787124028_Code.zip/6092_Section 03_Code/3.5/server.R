
function(input, output){
  
  # sanitise errors
  
  observe({
    
    options(shiny.sanitize.errors = input$sanitise)
  })
  
  # validate error
  
  output$avoidErrorTable = renderTable({
    
    if(is.null(input$file)) return()
    
    read.csv(input$file$datapath)
  })
  
  # validate error
  
  output$validateErrorTable = renderTable({
    
    validate(
      need(input$file, "You haven't selected a file")
    )
    
    read.csv(input$file$datapath)
    
  })
  
  # show error
  
  output$showErrorTable = renderTable({
    
    if(is.null(input$file)) stop("You haven't selected a file")
    
    read.csv(input$file$datapath)
  })
  
  # always show error
  
  output$alwaysShowErrorTable = renderTable({
    
    if(is.null(input$file)) stop(safeError("You haven't selected a file"))
    
    read.csv(input$file$datapath)
  })
  
  # catch other errors
  
  output$catchErrorTable = renderTable({
    
    tryCatch(read.csv(input$file$datapath), error = function(error) 
      stop(safeError(error)))
    
  })

}