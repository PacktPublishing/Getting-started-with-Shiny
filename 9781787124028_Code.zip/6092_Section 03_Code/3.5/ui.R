fluidPage(
  
  titlePanel("Error handling"),
  
  sidebarLayout(
    sidebarPanel(
      checkboxInput("sanitise", "Sanitise errors?"),
      fileInput("file", "Upload data")
    ),
    
    mainPanel(
      tabsetPanel(
        tabPanel("Avoid error", tableOutput("avoidErrorTable")),
        tabPanel("Validate error", tableOutput("validateErrorTable")),
        tabPanel("Show error", tableOutput("showErrorTable")),
        tabPanel("Always show error", tableOutput("alwaysShowErrorTable")),
        tabPanel("Catch other errors", tableOutput("catchErrorTable"))
      )
    )
  )
)