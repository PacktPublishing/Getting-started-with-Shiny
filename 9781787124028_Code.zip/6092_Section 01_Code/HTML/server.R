function(input, output){
  
  output$thePlot <- renderPlot({
    
    plot(1:10, main = input$title)
  })
}