
server = function(input, output){
  
  output$thePlot <- renderPlot({
    
    plot(1:10, main = input$title)
  })
}

ui = fluidPage(
  
  # Title panel
  titlePanel("Title the graph"),
  
  # Typical sidebar layout with text input
  sidebarLayout(
    sidebarPanel(
      textInput("title", "Title", value = "Your title here")
    ),
    
    # Plot is placed in main panel
    mainPanel(
      plotOutput("thePlot")
    )
  )
)

shinyApp(ui = ui, server = server, options = list(height = 500))