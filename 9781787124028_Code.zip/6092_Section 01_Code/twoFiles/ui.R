fluidPage(
  
  # Title panel
  titlePanel("Title the graph"),
  
  # Typical sidebar layout with text input
  sidebarLayout(
    sidebarPanel(
      textInput("title", "Title", value = "Your title here")
    ),
    
    # Plot is placed in main panel
    mainPanel(
      plotOutput("thePlot")
    )
  )
)
