fluidPage(
  
  # Title panel
  titlePanel("Title the graph"),
  
  # Typical sidebar layout with text input
  sidebarLayout(
    sidebarPanel(
       textInput("title", "Plot title", value = "Your title here")
    ),
    
    # Plot is placed in main panel
    mainPanel(
       plotOutput("moviePlot")
    )
  )
)
