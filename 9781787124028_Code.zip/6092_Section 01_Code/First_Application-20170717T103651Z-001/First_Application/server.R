
library(ggplot2movies)
library(tidyverse)
library(scales)

function(input, output) {
  
  # reactive plot
   
  output$moviePlot = renderPlot({
    
    # set up data
    
    budgetByYear = summarise(group_by(movies, year), 
                             m = mean(budget, na.rm= TRUE))
    
    # plot
    
    ggplot(budgetByYear[complete.cases(budgetByYear), ], 
           aes(x = year, y = m)) +  geom_line() + 
      scale_y_continuous(labels = scales::comma) +
      ggtitle(input$title)
  })
  
}
