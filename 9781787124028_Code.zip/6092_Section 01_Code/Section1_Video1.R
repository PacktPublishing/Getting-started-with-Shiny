### section 1, video 1

2 + 2

# Installing R, RStudio, and Shiny and running the examples

install.packages("shiny")

library(shiny)

runExample("01_hello", launch.browser = TRUE) # run
runExample("02_text", launch.browser = TRUE)
runExample("03_reactivity", launch.browser = TRUE)
runExample("04_mpg", launch.browser = TRUE)
runExample("05_sliders", launch.browser = TRUE)
runExample("06_tabsets", launch.browser = TRUE) # run
runExample("07_widgets", launch.browser = TRUE)
runExample("08_html", launch.browser = TRUE) # run
runExample("09_upload", launch.browser = TRUE)
runExample("10_download", launch.browser = TRUE)
runExample("11_timer", launch.browser = TRUE)
